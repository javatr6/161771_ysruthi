package com.capgemini.BusJpa;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Table(name="Buspassreq")
@Entity
public class BussPassBean {

	@Id
	@GeneratedValue
	private Integer requestId;
	private String employeeid;
	private String firstName;
	private String lastName;
	private String gender;
	private String address;
	private LocalDate doj;
	private String emailId;
	private String location;
	private String pickupLocation;
	private String designation;
	private LocalTime pickupTime;
	
	private String status="Pending";
	@OneToMany
	@JoinColumn
	private RouteMapBean route;
	
	public  BussPassBean() {
		
	}
	public BussPassBean(Integer requestId, String employeeid, String firstName, String lastName, String gender,
			String address, LocalDate doj, String emailId, String location, String pickupLocation, String designation,
			LocalTime pickupTime, String status) {
		super();
		this.requestId = requestId;
		this.employeeid = employeeid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.address = address;
		this.doj = doj;
		this.emailId = emailId;
		this.location = location;
		this.pickupLocation = pickupLocation;
		this.designation = designation;
		this.pickupTime = pickupTime;
		this.status = status;
	}
	
	
	
	public BussPassBean(String employeeid, String firstName, String lastName, String gender, String address,
			LocalDate doj, String emailId, String location, String pickupLocation, String designation,
			LocalTime pickupTime, String status) {
		super();
		this.employeeid = employeeid;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.address = address;
		this.doj = doj;
		this.emailId = emailId;
		this.location = location;
		this.pickupLocation = pickupLocation;
		this.designation = designation;
		this.pickupTime = pickupTime;
		this.status = status;
	}
	public Integer getRequestId() {
		return requestId;
	}

	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}

	public String getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public LocalDate getDoj() {
		return doj;
	}

	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPickupLocation() {
		return pickupLocation;
	}

	public void setPickupLocation(String pickupLocation) {
		this.pickupLocation = pickupLocation;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public LocalTime getPickupTime() {
		return pickupTime;
	}

	public void setPickupTime(LocalTime pickupTime) {
		this.pickupTime = pickupTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	
	public RouteMapBean getRoute() {
		return route;
	}
	public void setRoute(RouteMapBean route) {
		this.route = route;
	}
	@Override
	public String toString() {
		return "BussPassBean [requestId=" + requestId + ", employeeid=" + employeeid + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", gender=" + gender + ", address=" + address + ", doj=" + doj
				+ ", emailId=" + emailId + ", location=" + location + ", pickupLocation=" + pickupLocation
				+ ", designation=" + designation + ", pickupTime=" + pickupTime + ", status=" + status + "]";
	}
	
}
