package com.capgemini.BusJpa;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Tester {

	public static void main(String[] args) {

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		BussPassBean sri=new BussPassBean("4373_SA","sri","kamala","Female","Chennai",
				LocalDate.of(2018, 10,11),"sri@gmail.com","Chennai SIPCOT","Chennai MIPL","Tambaram",
				LocalTime.of(9,45),"Pending");
		
		AdminLoginBean login=new AdminLoginBean("sai","sai123");
		
		RouteMapBean route=new RouteMapBean(05,"ChennaiMIPL,Tambaram",10,60,"TN634","Rajesh",30);
		
		RouteMapBean route1= new RouteMapBean(06,sri,"ChennaiMIPL,Tambaram",5,
			60,"TN244","Sai",30);
		sri.setRoute(route1);
		TransactionBean transactions=new TransactionBean(route,"1617_NS", LocalDate.of(2018,11,23),35.00,5000);
		entityManager.persist(sri);
		entityManager.persist(login);
		entityManager.persist(route);
		entityManager.persist(route1);
		entityManager.persist(transactions);
		transaction.commit();
		entityManager.close();
		
	}

}
