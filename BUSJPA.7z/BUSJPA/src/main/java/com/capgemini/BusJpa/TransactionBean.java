package com.capgemini.BusJpa;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Table(name="TransactionDetails")
@Entity
public class TransactionBean {
	@Id
	@GeneratedValue
	private Integer transactionid;

	@OneToOne
	@JoinColumn(name="RouteId")
	private RouteMapBean route;
	
	private String empid;
	private LocalDate transactiondate;
	private Double totalkm;
	private Integer monthlyfare;
	
	
	public TransactionBean() {
		super();
	}


	public Integer getTransactionid() {
		return transactionid;
	}


	public void setTransactionid(Integer transactionid) {
		this.transactionid = transactionid;
	}


	public RouteMapBean getRoute() {
		return route;
	}


	public void setRoute(RouteMapBean route) {
		this.route = route;
	}


	public String getEmpid() {
		return empid;
	}


	public void setEmpid(String empid) {
		this.empid = empid;
	}


	public LocalDate getTransactiondate() {
		return transactiondate;
	}


	public void setTransactiondate(LocalDate transactiondate) {
		this.transactiondate = transactiondate;
	}


	public Double getTotalkm() {
		return totalkm;
	}


	public void setTotalkm(Double totalkm) {
		this.totalkm = totalkm;
	}


	public Integer getMonthlyfare() {
		return monthlyfare;
	}


	public void setMonthlyfare(Integer monthlyfare) {
		this.monthlyfare = monthlyfare;
	}


	@Override
	public String toString() {
		return "TransactionBean [transactionid=" + transactionid + ", route=" + route + ", empid=" + empid
				+ ", transactiondate=" + transactiondate + ", totalkm=" + totalkm + ", monthlyfare=" + monthlyfare
				+ "]";
	}


	public TransactionBean(RouteMapBean route, String empid, LocalDate transactiondate, Double totalkm,
			Integer monthlyfare) {
		super();
		this.route = route;
		this.empid = empid;
		this.transactiondate = transactiondate;
		this.totalkm = totalkm;
		this.monthlyfare = monthlyfare;
	}


	public TransactionBean(String empid, LocalDate transactiondate, Double totalkm, Integer monthlyfare) {
		super();
		this.empid = empid;
		this.transactiondate = transactiondate;
		this.totalkm = totalkm;
		this.monthlyfare = monthlyfare;
	}


	public TransactionBean(Integer transactionid, String empid, LocalDate transactiondate, Double totalkm,
			Integer monthlyfare) {
		super();
		this.transactionid = transactionid;
		this.empid = empid;
		this.transactiondate = transactiondate;
		this.totalkm = totalkm;
		this.monthlyfare = monthlyfare;
	}
	
    

}


