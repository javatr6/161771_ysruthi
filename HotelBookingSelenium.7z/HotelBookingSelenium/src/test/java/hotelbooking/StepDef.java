package hotelbooking;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver driver;
	
	
	@Before
	public void setup() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:8081/HotelBookingSelenium/hotelbooking.html");
		String  element=driver.findElement(By.xpath("/html/body/div/h2")).getText();
		   assertEquals(element,"Hotel Booking Form");
	
	}
	
	
	@Given("^Valid User Details$")
	public void valid_User_Details() throws Throwable {
		driver.findElement(By.id("txtFirstName")).sendKeys("sai");
		driver.findElement(By.id("txtLastName")).sendKeys("sruthi");
		driver.findElement(By.id("txtEmail")).sendKeys("sai@gmail.com");
		driver.findElement(By.id("txtPhone")).sendKeys("7098765678");
		driver.findElement(By.tagName("textarea")).sendKeys("Chennai");
		Select city=new Select(driver.findElement(By.name("city")));
		city.selectByVisibleText("Hyderabad");
		Select state=new Select(driver.findElement(By.name("state")));
		state.selectByVisibleText("Telangana");
		Select persons=new Select(driver.findElement(By.name("persons")));
		persons.selectByVisibleText("1");
		driver.findElement(By.id("txtCardholderName")).sendKeys("sai");
		driver.findElement(By.id("txtDebit")).sendKeys("345678765");
		driver.findElement(By.name("cvv")).sendKeys("346");
		driver.findElement(By.id("txtMonth")).sendKeys("December");
		driver.findElement(By.id("txtYear")).sendKeys("2023");
		Thread.sleep(2000);
	}

	@When("^On Submit$")
	public void on_Submit() throws Throwable {
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(2000);

	}

	@Then("^Navigate to Success page$")
	public void navigate_to_Success_page() throws Throwable {
		Thread.sleep(1000);

	}

	@Given("^Invalid User Details$")
	public void invalid_User_Details() throws Throwable {
		driver.findElement(By.id("txtFirstName")).sendKeys("sri");
		driver.findElement(By.id("txtLastName")).sendKeys("latha");
		driver.findElement(By.id("txtEmail")).sendKeys("sri@gmail.com");
		driver.findElement(By.id("txtPhone")).sendKeys("7865456789");
		driver.findElement(By.tagName("textarea")).sendKeys("Pune");
		Select city=new Select(driver.findElement(By.name("city")));
		city.selectByVisibleText("Hyderabad");
		Select state=new Select(driver.findElement(By.name("state")));
		state.selectByVisibleText("Telangana");
		Select persons=new Select(driver.findElement(By.name("persons")));
		persons.selectByVisibleText("1");
		driver.findElement(By.id("txtCardholderName")).sendKeys("sri");
		driver.findElement(By.id("txtDebit")).sendKeys("675467897");
		driver.findElement(By.name("cvv")).sendKeys("564");
		driver.findElement(By.id("txtMonth")).sendKeys("October");
		driver.findElement(By.id("txtYear")).sendKeys("");
		Thread.sleep(2000);

	}

	@Then("^Display the error message$")
	public void display_the_error_message() throws Throwable {
		driver.switchTo().alert().accept();
		driver.findElement(By.id("txtYear")).sendKeys("2025");
	    driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(2000);

	}
	
	@After
	public void teardown() {
		//driver.quit();
	}



}
