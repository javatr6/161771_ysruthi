package com.cap.Inheritence;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager = emf.createEntityManager();
		
		entityManager.getTransaction().begin();
		Project proj=new Project(123,"java");
		Module module=new Module();
		module.setModuleName("Oracle");
		module.setProjectId(67234);
		module.setProjectName("oracle");
		Task tsk=new Task();
		tsk.setTaskName("java beans");
		tsk.setProjectName("oracle server");
		entityManager.persist(proj);
		entityManager.persist(module);
		entityManager.persist(tsk);
		entityManager.getTransaction().commit();

	}

}
