package com.cap.Inheritence;

import javax.persistence.Entity;

@Entity
public class Module extends Project{

	private String moduleName;
	
	public Module(){
		
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	@Override
	public String toString() {
		return "Module [moduleName=" + moduleName + "]";
	}
	
}
