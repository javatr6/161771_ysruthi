package com.cap.Inheritence;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy=InheritanceType.JOINED)
public class Project {
 
	@Id
	private int projectId;
	private String ProjectName;
	
	public Project(){
		
	}

	public Project(int projectId, String projectName) {
		super();
		this.projectId = projectId;
		ProjectName = projectName;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return ProjectName;
	}

	public void setProjectName(String projectName) {
		ProjectName = projectName;
	}

	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", ProjectName=" + ProjectName + "]";
	}
	
	
}
