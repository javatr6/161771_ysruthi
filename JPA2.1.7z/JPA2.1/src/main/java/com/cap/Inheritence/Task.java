package com.cap.Inheritence;

import javax.persistence.Entity;

@Entity
public class Task extends Module{
	
	private String TaskName;
	

	public Task() {
		
	}


	public Task(String taskName) {
		super();
		TaskName = taskName;
	}


	public String getTaskName() {
		return TaskName;
	}


	public void setTaskName(String taskName) {
		TaskName = taskName;
	}


	@Override
	public String toString() {
		return "Task [TaskName=" + TaskName + "]";
	}
	
}

