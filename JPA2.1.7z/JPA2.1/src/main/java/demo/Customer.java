package demo;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Customer {

	@Id
	@GeneratedValue 
	private Integer custId;
	private String firstname;
	private String LastName;
	private Double regfess;
	private LocalDate regdate;
	
	@OneToOne
	@JoinColumn(name="addrFk")
	private Address address;


	public Customer(String firstname, String lastName, Double regfess, LocalDate regdate) {
		super();
		this.firstname = firstname;
		LastName = lastName;
		this.regfess = regfess;
		this.regdate = regdate;
	}

	public Integer getCustId() {
		return custId;
	}

	public void setCustId(Integer custId) {
		this.custId = custId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public Double getRegfess() {
		return regfess;
	}

	public void setRegfess(Double regfess) {
		this.regfess = regfess;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	

	public LocalDate getRegdate() {
		return regdate;
	}

	public void setRegdate(LocalDate regdate) {
		this.regdate = regdate;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", firstname=" + firstname + ", LastName=" + LastName + ", regfess="
				+ regfess + ", address=" + address + "]";
	}
	
	
	

}
