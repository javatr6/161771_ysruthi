package demo;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
			
			EntityManager entityManager = emf.createEntityManager();
			
			entityManager.getTransaction().begin();
			
			Customer customer =new Customer("sai","sruthi",7234.87,LocalDate.now());
			Customer customer1 =new Customer("sri","kala",289346.87,LocalDate.of(2018, 1, 22));
			Address adr=new Address("chennai",customer);
		//	Address adr1=new Address("Hyderabad",customer1);
			customer.setAddress(adr);
			customer1.setAddress(adr);
			entityManager.persist(customer); 
			entityManager.persist(adr);
		    entityManager.persist(customer1); 
			//entityManager.persist(adr1);
			
			entityManager.getTransaction().commit();
	}

}
