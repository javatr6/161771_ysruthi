package map2;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employees {

	@Id
	private int EmployeeId;
	private String EmployeeName;
	@ManyToOne
	@JoinColumn(name="capFk")
	private Company company;
	
	
	public Employees() {
		
	}


	public Employees(int employeeId, String employeeName, Company company) {
		super();
		EmployeeId = employeeId;
		EmployeeName = employeeName;
		this.company = company;
	}


	public int getEmployeeId() {
		return EmployeeId;
	}


	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}


	public String getEmployeeName() {
		return EmployeeName;
	}


	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}


	public Company getCompany() {
		return company;
	}


	public void setCompany(Company company) {
		this.company = company;
	}


	@Override
	public String toString() {
		return "Employees [EmployeeId=" + EmployeeId + ", EmployeeName=" + EmployeeName + ", company=" + company + "]";
	}
	
	
}
