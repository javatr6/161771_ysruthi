package map2;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Main {
	
	public static void main(String args[]) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager = emf.createEntityManager();
		
		entityManager.getTransaction().begin();
		
		Company comp=new Company("CapGemini");
		Company comp1=new Company("TCS");
		
		Employees emp=new Employees(6754,"sai",comp);
		Employees emp1=new Employees(3754,"sruthi",comp1);
	
		entityManager.persist(comp); 
		entityManager.persist(comp1);
		entityManager.persist(emp); 
		entityManager.persist(emp1);
	
	
		entityManager.getTransaction().commit();
	}

}
