package map3;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Events {
	
	@Id
	private int eventId;
	private String eventName;
	
	@ManyToMany
	@JoinTable(name="event_delegate" ,
	joinColumns= {@JoinColumn(name="events")},
	inverseJoinColumns= {@JoinColumn(name="delegates")})
	
	List<Delegates> delegates=new ArrayList<Delegates>();
	
	public Events() {
		
	}

	
	public Events(int eventId, String eventName, List<Delegates> delegates) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.delegates = delegates;
	}



	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public List<Delegates> getDelegates() {
		return delegates;
	}

	public void setDelegates(List<Delegates> delegates) {
		this.delegates = delegates;
	}

	@Override
	public String toString() {
		return "Events [eventId=" + eventId + ", eventName=" + eventName + ", delegates=" + delegates + "]";
	}
	
	
	

}
