package com.cap.inheritance;

public class Module extends Project{

}
