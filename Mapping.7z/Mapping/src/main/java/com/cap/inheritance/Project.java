package com.cap.inheritance;

import javax.persistence.Entity;

@Entity

public class Project {

	private int projectId;
	private int projectName;
}
