package com.cap.inheritance;

public class Task extends Module{

}
