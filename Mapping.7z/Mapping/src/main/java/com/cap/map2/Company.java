package com.cap.map2;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Company {
	
	@Id
	@GeneratedValue
	private Integer companyId;
	private String CompanyName;
	
	@OneToMany(mappedBy="company",targetEntity=Employees.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	List<Employees> emp=new ArrayList<Employees>();
	
	public Company() {
		
	}

	public Company(String companyName) {
		super();
		CompanyName = companyName;
		
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

	public List<Employees> getEmp() {
		return emp;
	}

	public void setEmp(List<Employees> emp) {
		this.emp = emp;
	}

	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", CompanyName=" + CompanyName + ", emp=" + emp + "]";
	}
	
	

}
