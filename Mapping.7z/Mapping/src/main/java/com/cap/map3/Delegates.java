package com.cap.map3;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Delegates {
	
	@Id
	private int delegateId;
	private String DelegateName;
	
	@ManyToMany
	@JoinTable(name="event_delegate" ,
	joinColumns= {@JoinColumn(name="delegates")},
	inverseJoinColumns= {@JoinColumn(name="events")})
	
	List<Events> events=new ArrayList<Events>();
	
	public Delegates() {
		
	}

	public Delegates(int delegateId, String delegateName) {
		super();
		this.delegateId = delegateId;
		DelegateName = delegateName;
	
	}

	public Delegates(int delegateId, String delegateName, List<Events> events) {
		super();
		this.delegateId = delegateId;
		DelegateName = delegateName;
		this.events = events;
	}

	public int getDelegateId() {
		return delegateId;
	}

	public void setDelegateId(int delegateId) {
		this.delegateId = delegateId;
	}

	public String getDelegateName() {
		return DelegateName;
	}

	public void setDelegateName(String delegateName) {
		DelegateName = delegateName;
	}

	public List<Events> getEvents() {
		return events;
	}

	public void setEvents(List<Events> events) {
		this.events = events;
	}

	@Override
	public String toString() {
		return "Delegates [delegateId=" + delegateId + ", DelegateName=" + DelegateName + ", events=" + events + "]";
	}
	

}
