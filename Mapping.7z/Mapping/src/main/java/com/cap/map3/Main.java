package com.cap.map3;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Main {

	public static void main(String[] args) {

		

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
			
			EntityManager entityManager = emf.createEntityManager();
			
			entityManager.getTransaction().begin();
			Events java=new Events();
			Events oracle=new Events();
			Events BigData=new Events();
			java.setEventName("java");
			java.setEventId(67);
			oracle.setEventName("Oracle");
			oracle.setEventId(56);
			BigData.setEventName("BigData");
			BigData.setEventId(10);
			
			Delegates delg1=new Delegates(12,"kamal");
			Delegates delg2=new Delegates(13,"sri");
			Delegates delg3=new Delegates(65,"kalapana");
			Delegates delg4=new Delegates(78,"sitha");
			Delegates delg5=new Delegates(45,"ayar");
			delg1.getEvents().add(java);
			delg2.getEvents().add(oracle);
			delg3.getEvents().add(java);
			delg4.getEvents().add(BigData);
			delg3.getEvents().add(BigData);
			delg5.getEvents().add(oracle);
			delg5.getEvents().add(java);
			delg1.getEvents().add(oracle);
				
			
			entityManager.persist(java); 
			entityManager.persist(oracle);
			entityManager.persist(BigData);
			entityManager.persist(delg3);
			entityManager.persist(delg4);
			entityManager.persist(delg5);
			entityManager.persist(delg1);
			entityManager.persist(delg1);
			
			entityManager.getTransaction().commit();
	}

}
