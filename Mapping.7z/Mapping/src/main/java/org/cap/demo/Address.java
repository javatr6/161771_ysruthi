package org.cap.demo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {

	@Id
	private int addrsId;
	private String address;
	

	@OneToOne
	@JoinColumn(name="custFk")
	private Customer customer;
    
	public Address() {
		
	}

	public Address(String address, Customer customer) {
		super();
		
		this.address = address;
		this.customer = customer;
	}

	public int getAddrsId() {
		return addrsId;
	}

	public void setAddrsId(int addrsId) {
		this.addrsId = addrsId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Address [addrsId=" + addrsId + ", address=" + address + ", customer=" + customer + "]";
	}
	

}
