package org.cap.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
			
			EntityManager entityManager = emf.createEntityManager();
			
			entityManager.getTransaction().begin();
			
			Customer customer =new Customer("sai","sruthi",7234.87);
			Address adr=new Address("chennai",customer);
			customer.setAddress(adr);
			entityManager.persist(customer); 
			entityManager.persist(adr);
		
			entityManager.getTransaction().commit();
	}

}
