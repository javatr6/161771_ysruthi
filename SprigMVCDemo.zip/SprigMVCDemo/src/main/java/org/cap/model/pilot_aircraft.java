package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class pilot_aircraft {
	@Id
private int pilotId;
private String aircraftId;
public pilot_aircraft(int pilotId, String aircraftId) {
	super();
	this.pilotId = pilotId;
	this.aircraftId = aircraftId;
}
public pilot_aircraft() {
	super();
}
public int getPilotId() {
	return pilotId;
}
public void setPilotId(int pilotId) {
	this.pilotId = pilotId;
}
public String getAircraftId() {
	return aircraftId;
}
public void setAircraftId(String aircraftId) {
	this.aircraftId = aircraftId;
}
@Override
public String toString() {
	return "pilot_aircraft [pilotId=" + pilotId + ", aircraftId=" + aircraftId + "]";
}


}
